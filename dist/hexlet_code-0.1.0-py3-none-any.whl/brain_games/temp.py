from random import choice
from operator import *
from functools import reduce

d = {'+': add,
     '-': sub,
     '*': mul}

f = choice(['+', '-', '*'])
num1 = 10
num2 = 5


correct = reduce(d[f], [num1, num2])
print(correct)
